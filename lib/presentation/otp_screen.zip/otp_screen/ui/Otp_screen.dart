import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sms_otp_auto_verify/sms_otp_auto_verify.dart';

import '../../../common/textfont/textfont.dart';
import '../../../main.dart';
import '../../home_page/ui/homescreen.dart';
import '../../login_page/ui/login_screen.dart';
import '../bloc/otpscreen_bloc.dart';

class OtpScreenWrapper extends StatelessWidget {
  const OtpScreenWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => OtpscreenBloc(),
      child: const OtpScreen(),
    );
  }
}

class OtpScreen extends StatelessWidget {
  const OtpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final otpController = TextEditingController();

    return Scaffold(
      backgroundColor: const Color(0xFFFFFFFF),
      appBar: AppBar(
        forceMaterialTransparency: true,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(
                builder: (context) => const LoginScreenWrapper(),
              ),
            );
          },
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
        ),
      ),
      body: BlocConsumer<OtpscreenBloc, OtpscreenState>(
        listener: (context, state) {
          if (state is OtpVerificationSuccess) {
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(builder: (context) => const HomescreenWrapper()),
            );
          } else if (state is OtpVerificationFailure) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(state.error)),
            );
          }
        },
        builder: (context, state) {
          bool enableButton = false;
          bool isLoading = false;
          String countdownText = "Resend SMS";

          if (state is OtpCodeUpdated) {
            enableButton = state.enableButton;
            isLoading = state.isLoading;
          } else if (state is CountdownRunning) {
            countdownText = "Resend SMS in ${state.secondsRemaining} sec";
          }

          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                const TextThemedel(
                  text: "Enter OTP",
                  color: Color(0xFF000000),
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
                const TextThemedel(
                  text: "OTP has been sent to XX-XX-XX-XX-XX",
                  color: Color(0xFFADADAD),
                  fontSize: 10,
                ),
                const SizedBox(height: 10),
                TextFieldPin(
                  textController: otpController,
                  autoFocus: true,
                  codeLength: 4,
                  alignment: MainAxisAlignment.center,
                  defaultBoxSize: 46.0,
                  margin: 10,
                  selectedBoxSize: 46.0,
                  textStyle: const TextStyle(fontSize: 16),
                  defaultDecoration: BoxDecoration(
                    color: const Color(0xffffffff),
                    border: Border.all(
                      color: const Color(0xff0e2f0e),
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  selectedDecoration: BoxDecoration(
                    color: const Color(0xff2fa134),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(
                      color: const Color(0xff0e2f0e),
                      width: 1,
                    ),
                  ),
                  onChange: (code) {
                    context.read<OtpscreenBloc>().add(OtpCodeChanged(code));
                    print("code : $code");
                  },
                ),
                const SizedBox(height: 10),
                TextThemedel(
                  text: countdownText,
                  color: const Color(0xFFADADAD),
                  fontSize: 10,
                ),
                const SizedBox(height: 10),
                MaterialButton(
                  elevation: 5,
                  onPressed: enableButton
                      ? () {
                    context.read<OtpscreenBloc>().add(VerifyOtp());
                  }
                      : null,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  color: enableButton
                      ? const Color(0xff2fa134)
                      : const Color(0xffcecece),
                  minWidth: MyApp.width * .6,
                  height: MyApp.height * .06,
                  child: isLoading
                      ? const CircularProgressIndicator(
                    color: Colors.white,
                  )
                      : const TextThemedel(
                    text: "Continue",
                    color: Color(0xFFFFFFFF),
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                MaterialButton(
                  onPressed: state is CountdownComplete
                      ? () {
                    context.read<OtpscreenBloc>().add(StartCountdown());
                    // Logic to resend OTP can be added here
                  }
                      : null,
                  color: const Color(0xff2fa134),
                  child: const Text("Resend OTP"),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
