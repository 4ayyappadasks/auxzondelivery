part of 'otpscreen_bloc.dart';

@immutable
sealed class OtpscreenEvent {}

class OtpCodeChanged extends OtpscreenEvent {
  final String otpCode;

  OtpCodeChanged(this.otpCode);
}

class VerifyOtp extends OtpscreenEvent {}

class StartCountdown extends OtpscreenEvent {}
