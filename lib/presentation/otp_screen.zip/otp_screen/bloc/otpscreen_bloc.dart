import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'otpscreen_event.dart';
part 'otpscreen_state.dart';

class OtpscreenBloc extends Bloc<OtpscreenEvent, OtpscreenState> {
  final int otpCodeLength = 4;
  final int countdownDuration = 30;
  Timer? _countdownTimer;

  OtpscreenBloc() : super(OtpscreenInitial()) {
    on<OtpCodeChanged>((event, emit) {
      final otpCode = event.otpCode;
      bool enableButton = otpCode.length == otpCodeLength;
      emit(OtpCodeUpdated(
        otpCode: otpCode,
        enableButton: enableButton,
        isLoading: false,
      ));
    });

    on<VerifyOtp>((event, emit) async {
      emit(OtpVerificationInProgress());
      try {
        // Simulate OTP verification success
        emit(OtpVerificationSuccess());
      } catch (e) {
        emit(OtpVerificationFailure('OTP verification failed. Please try again.'));
      }
    });

    on<StartCountdown>((event, emit) {
      _startCountdown(emit);
    });
  }

  void _startCountdown(Emitter<OtpscreenState> emit) {
    int secondsRemaining = countdownDuration;
    emit(CountdownRunning(secondsRemaining));

    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      secondsRemaining--;
      if (secondsRemaining > 0) {
        emit(CountdownRunning(secondsRemaining));
      } else {
        timer.cancel();
        emit(CountdownComplete());
      }
    });
  }

  @override
  Future<void> close() {
    _countdownTimer?.cancel();
    return super.close();
  }
}
