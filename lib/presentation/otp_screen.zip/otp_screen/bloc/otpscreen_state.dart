part of 'otpscreen_bloc.dart';

@immutable
sealed class OtpscreenState {}

class OtpscreenInitial extends OtpscreenState {}

class OtpCodeUpdated extends OtpscreenState {
  final String otpCode;
  final bool enableButton;
  final bool isLoading;

  OtpCodeUpdated({
    required this.otpCode,
    required this.enableButton,
    required this.isLoading,
  });
}

class OtpVerificationInProgress extends OtpscreenState {}

class OtpVerificationSuccess extends OtpscreenState {}

class OtpVerificationFailure extends OtpscreenState {
  final String error;

  OtpVerificationFailure(this.error);
}

class CountdownRunning extends OtpscreenState {
  final int secondsRemaining;

  CountdownRunning(this.secondsRemaining);
}

class CountdownComplete extends OtpscreenState {}
